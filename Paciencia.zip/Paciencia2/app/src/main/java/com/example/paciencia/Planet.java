package com.example.paciencia;

public class Planet {
    public String name;
    public int rotation_period;
    public int orbital_period;
    public int diameter;
    public String climate;
    public int gravity;
    public String terrain;
    public int surface_water;
    public int population;

}
