package com.example.paciencia;

import java.util.List;

public class StarPlanets {
    public List <Planet> planets;

}
